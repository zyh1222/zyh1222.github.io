# Examples of the Simple Search Service using SimpleSearchJS
  
  
## nostyle.html

![nostyle](img/nostyle-sm.png)
  
  
## cards.html

![cards](img/cards-sm.png)
  
  
## classic.html

![classic](img/classic-sm.png)
  
  
## fragments.html

![fragments](img/fragments-sm.png)
  
  
